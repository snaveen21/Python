# Move Parquet files

Python utility script to backup parquet files in HDFS paths.


# Requirements

* Hive table smallfiles.fsimage_disco with list of file paths and modification date
* Valid Kerberos ticket to run with permissions on affected paths
* Snakebite python package


# Package

```
zip -r mv_np_parquet_files.zip mv_np_parquet_files
```


# Run

1. Upload package to edge node
```
scp mv_np_parquet_files.zip m386:
```
2. unpack
```
ssh m386
unzip mv_np_parquet_files.zip
```
3. run (e.g. Greece, move all files created on 2018-05-04)
```
ssh m386
python mv_np_parquet_files/main.py  -o gr -d 20180504 -i vgddp360hr
```

