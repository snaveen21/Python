import os


def path():
    return os.path.dirname(__file__)
