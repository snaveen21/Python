from datetime import datetime as dt
import getopt
import logging
import sys
import time
from snakebite.client import AutoConfigClient


class ArgParser(object):
    def __init__(self):
        self.check_mode = False
        self.valid_opco_codes = ['gr', 'es', 'it', 'pt']
        self.opco_code = None
        self.the_date = None
        self.backup_suffix = None
        self.impala = None
        self.test_file = None

    @staticmethod
    def usage_help(exe_name):
        usage_string = """
        Usage: %s -o <opco_code> -d <the_date> -i <impala> [-t <test_file> -c]

        Options:
            -o, --opco_code=<2-bit opco_code>
                Set the opco_code for country

            -d, --the_date=<the date as YYYYMMDD int value>
                Set the date to run over

            -i, --impala=<the impala server>
                Set the impala server e.g. vgddp360hr milan discovery

            -t, --test_file=<full path to test file>
                Provide a test file with HDFS paths for a test run.

            -c, --check_mode
                Flag to indicate `Do not run any mv command`
        """ % exe_name

        return usage_string

    def validate(self):
        if not self.test_file:
            assert self.opco_code in self.valid_opco_codes, "opco_code not valid"

    def parse_args(self, commandline_args):
        self.orig_args = commandline_args
        try:
            opts, args = getopt.getopt(
                commandline_args,
                shortopts="ho:d:i:t:c",
                longopts=["help", "opco_code=", "the_date=", "impala=", "test_file=", "check_mode"]
            )

        except getopt.GetoptError as err:
            logging.error("Error: %s", str(err))
            print self.usage_help(sys.argv[0])
            sys.exit(1)

        for opt, arg in opts:
            if opt in ("-h", "--help"):
                print self.usage_help(sys.argv[0])
                sys.exit()

            elif opt in ("-o", "--opco_code"):
                self.opco_code = arg.lower()

            elif opt in ("-d", "--the_date"):
                self.the_date = dt.strptime(arg, '%Y%m%d').date().strftime('%Y-%m-%d')
                self.backup_suffix = 'bkp_' + arg

            elif opt in ("-i", "--impala"):
                self.impala = arg

            elif opt in ("-t", "--test_file"):
                self.test_file = arg

            elif opt in ("-c", "--check_mode"):
                self.check_mode = True

        if not self.opco_code and not self.test_file:
            logging.error("No opco code supplied. Mandatory when no test file provided. Please follow instructions.")
            print self.usage_help(sys.argv[0])
            sys.exit(1)

        if not self.the_date and not self.test_file:
            logging.error("No start date supplied. Mandatory when no test file provided. Please follow instructions.")
            print self.usage_help(sys.argv[0])
            sys.exit(1)

        if not self.impala and not self.test_file:
            logging.error("No impala server supplied. Mandatory when no test file provided. Please follow instructions.")
            print self.usage_help(sys.argv[0])
            sys.exit(1)

        self.validate()
        return self

    def __repr__(self):
        return "ArgParser(%s)" % str(self.__dict__)

    def __str__(self):
        return self.__repr__()
