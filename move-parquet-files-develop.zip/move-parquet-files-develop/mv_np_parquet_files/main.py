import commands
from datetime import datetime as dt
import getopt
import logging
import sys
import time
from snakebite.client import AutoConfigClient
from arg_parser import ArgParser


#
# CONSTANTS
#
parquet_dir = '/parquet'
log_file = '/var/tmp/mv_np_parquet_files-' + dt.now().strftime('%Y%m%d_%H%M%S') + '.log'
query_template = 'impala-shell -i %s -k -B --quiet -q\
 \"select t.path from smallfiles.fsimage_disco t \
WHERE t.path like \'/data/raw/vf_%s/netperform/1.1/parquet/year=2018/month=%s\' \
and t.mdate like \'%s%s\'\"'

#
# for testing only
#
def get_parquet_files(input_args):

    if not input_args.test_file:
        logging.error('Error, test file not provided')
        sys.exit(1)

    parquet_files = []
    with open(input_args.test_file) as in_file:
        for input_path in in_file:
            input_path = input_path[:-1]
            parquet_files.append(input_path)
    return parquet_files


def get_parquet_files_from_impala(input_args):

    query_cmd = query_template % (input_args.impala, input_args.opco_code, '%', input_args.the_date, '%')
    (status, output) = commands.getstatusoutput(query_cmd)

    if status != 0:
        logging.error('Error running impala query command %s', query_cmd)
        sys.exit(1)

    lines = output.splitlines()
    if len(output) < 3:
        logging.error('Less than expected lines (>2) whilst running impala query command %s', query_cmd)
        sys.exit(1)
        

    return lines[2:]

def parse_input_path(input_path, arg_parser):
    input_path_split = input_path.split(parquet_dir)
    output_path = input_path_split[0] + arg_parser.backup_suffix + parquet_dir + input_path_split[1]
    output_path_dir = output_path.rsplit('/', 1)[0]
    return (output_path, output_path_dir)


def configure_logging():
    log_format = '%(asctime)s %(levelname)s:%(message)s'
    logging.basicConfig(filename=log_file, format=log_format, level=logging.INFO)

    console = logging.StreamHandler()
    console.setLevel(logging.WARN)
    console.setFormatter(logging.Formatter(log_format))

    logging.getLogger("").addHandler(console)


def main():
    configure_logging()

    arg_parser = ArgParser()
    arg_parser.parse_args(sys.argv[1:])

    logging.info('Running with %s', arg_parser)

    hdfs_client = AutoConfigClient()

    file_list = []
    if arg_parser.test_file:
        file_list = get_parquet_files(arg_parser)
    else:
        file_list = get_parquet_files_from_impala(arg_parser)

    logging.info('Running for %s paths', len(file_list))

    for input_path in file_list:
        
        logging.info('Processing file %s ...' % input_path)
        if not hdfs_client.test(input_path, exists=True):
            logging.warn('Processing file %s SKIPPED (does not exist)', input_path)
            continue

        (output_path, output_path_dir) = parse_input_path(input_path, arg_parser)

        # create dir first if does not exist
        if not hdfs_client.test(output_path_dir, exists=True):
          logging.info('Processing file %s Creating dir %s...', input_path, output_path_dir)
          if not arg_parser.check_mode:
            list(hdfs_client.mkdir([output_path_dir], create_parent=True))

        # move file
        logging.info('Processing file %s Moving to %s...', input_path, output_path)
        if not arg_parser.check_mode:
            list(hdfs_client.rename([input_path], output_path))
        logging.info('Processing file %s DONE', input_path)


if __name__ == "__main__":
    main()

